package model;

import java.io.*;
import java.util.*;

public class model{
	
	static ArrayList<state> states =  new ArrayList<state>();
	static ArrayList<String> visited = new ArrayList<String>();
	
	//CONSTRUCTOR
	public model(){
	}
	
	//ADDING
	public static void addState(String name){		//new states
		states.add(new state(name));
	}
	
	public static boolean addRelation(String from, String to){	//complete
		for(state e: states){
			if(e.getName().equals(from)){
				e.addRelation(to);
				return true;
			}
		}
		return false;
	}
	
	public static boolean addValue(String name, String value){
		
		for(state e: states){
			if(e.getName().equals(name)){
				e.addValues(value);
				return true;
			}
		}
		return false;
	}
	
	//GETTING
	public static void getStates(){
		for(int i = 0; i < states.size(); i++){
			System.out.println(states.get(i).getName());
		}
	}
	
	public static void getValues(String name){
		for(state e: states){
			if(e.getName().equals(name)){
				e.getValues();
			}
		}
	}
	
	public static void getRelations(String name){
		for(int i = 0; i < states.size(); i++){
			if(states.get(i).getName() == name){
				states.get(i).getRelations();
				//System.out.print("Size "+states.size());
			}
		}
	}
	
	public static String[] getChilds(String name){
		for(state e:states){
			if(e.getName().equals(name)) return e.relationsToArray();
		}
		return null;
	}
	
	//UTILITIES
	public static int numberRelations(String name){
		for(state e: states){
			if(e.getName().equals(name)) return e.numberRelations();
		}
		return 0;
	}
	
	public static void printModel(){
		System.out.println("");
		for(state e: states){
			System.out.print("State:");
			System.out.println(e.getName());
			e.getValues();
			e.getRelations();
			e.getLabels();
			System.out.println("");
		}
	}
	
	public static boolean holds(String name, String label){
		for(state e : states){
			if(e.getName().equals(name)){
				if(e.inArray(label) == true || e.inLabel(label) == true){
					return true;
				}
			}
		}
		return false;
	}
        
        public static int numberLabels(){
            int i = 0;
            for(state e:states){
                i = i + e.numberLabels();
            }
            return i;
        }
	/*public void valuesToString(String name){
		String v;
		for(int i = 0; i < states.size(); i++){
			if(states.get(i).getName() == name){
				if(v != "")
					v += "," + states.get(i).getValues();
				else
					v = states.get(i).getValues();
			}
		}
	}*/
	
	//ctl functions
	
	public static void andOp(String[] n, String l){
		boolean x;
		for(state e : states){
			x = true;
			for(String s: n){
				if(!e.inArray(s) && !e.inLabel(s)){
					x = false;
					break;
				}
			}
			if(x){
				e.addLabel(l);
			}
		}
	}
	
	public static void orOp(String[] n, String l){
		boolean x;
		for(state e: states){
			x = false;
			for(String s: n){
				if(e.inArray(s) || e.inLabel(s)){
					x = true;
					break;
				}
			}
			if(x){
				e.addLabel(l);
			}
		}
	}
	
	public static void notOp(String s, String l){
		for(state e:states){
			if(e.inArray(s) == false && e.inLabel(s) == false){
				e.addLabel(l);
			}
		}
	}
	
	/*public static void AX(String name, String s, String l){
		for(state e:states){
			if(e.getName().equals(name)){
				String[] a = e.relationsToArray();
				for(int i = 0; i < a.length; i++){
					if(!holds(a[i],s)){
						x = false;
						break;
					}
				}
				if(x){
					e.label(l);
				}
			}
		}
	}*/
	
	public static void ctlOp(String op, String value, String label){
		if(op.equals("AX")){
			AX(value,label);
		}
		if(op.equals("EX")){
			EX(value,label);
		}
		if(op.equals("AG")){
			AG(value,label);
		}
                if(op.equals("EG")){
			EG(value,label);
		}
                if(op.equals("AF")){
			AF(value,label);
		}
                if(op.equals("EF")){
			EF(value,label);
		}
	}
	/************************X***********************************/
	public static void AX(String s, String l){
		boolean x;
		for(state e:states){
			x = true;
			String[] a = e.relationsToArray();
			for(int i = 0; i < a.length; i++){
				if(!holds(a[i],s)){
					x = false;
					break;
				}
			}
			if(x){
				if(!e.inLabel(s) && !e.inArray(s)) e.addLabel(l);
			}
		}
	}
	
	public static void EX(String s, String l){
		boolean x;
		for(state e:states){
			x = false;
			String[] a = e.relationsToArray();
			for(int i = 0; i < a.length; i++){
				if(holds(a[i],s)){
					x = true;
					break;
				}
			}
			if(x){
				e.addLabel(l);
			}
		}
	}
	/**********************G********************************/
	public static void AG(String s, String l){
		for(state e: states){
                    boolean x;
                    visited = new ArrayList<String>();
                    x = evalChilds(e.getName(),s,l);
                    //System.out.println(e.getName() + x);
                    if(x){
                        e.addLabel(l);
                    }
		}
	}
	
	public static boolean evalChilds(String name, String s, String l){
		boolean x = true;
		if(visited(name)) return true;
		visited.add(name);
		if(!holds(name,s)) return false;
		String a[];
		a = getChilds(name);
		for(int i = 0; i < a.length; i++){
			x = evalChilds(a[i],s,l);
			if(!x) return false;
		}
		return true;
	}
	
        public static void EG(String s, String l){
		for(state e: states){
                    boolean x;
                    x = evalChildsE(e.getName(),s,l);
                    visited = new ArrayList<String>();
                    //System.out.println(e.getName() + x);
                    if(x){
                        e.addLabel(l);
                    }
		}
	}
        
        public static boolean evalChildsE(String name, String s, String l){
            boolean x = true;
            if(visited(name)) return true;
            visited.add(name);
            if(!holds(name,s)) return false;
            String a[];
            a = getChilds(name);
            for(int i = 0; i < a.length; i++){
                x = evalChilds(a[i],s,l);
                if(x) return true;
            }
            return false;
        }
        /*******************F**********************************/
        
        public static void AF(String s, String l){
            int before, after;
            for(state e:states){
                if(e.inLabel(s) || e.inArray(s)) e.addLabel(l);
            }
            do{
                before = numberLabels();
                AX(l,l);
                after = numberLabels();
            }while(before != after);
            
		/*for(state e: states){
                    boolean x = false;
                    String a[];
                    a = getChilds(e.getName());
                    for(int i = 0; i < a.length; i++){
                        visited = new ArrayList<String>();
                        x = evalChildAF(e.getName(),s,l);
                        System.out.println(e.getName() + x);
                        if(!x) break;
                    }
                    if(x){
                        e.addLabel(l);
                    }
		}*/
	}
	
//	public static boolean evalChildAF(String name, String s, String l){
		/*boolean x = true;
		if(visited(name)) return false;
		visited.add(name);
		if(holds(name,s)) return true;
		String a[];
		a = getChilds(name);
		for(int i = 0; i < a.length; i++){
			x = evalChilds(a[i],s,l);
			if(!x) return false;
		}
		return false;*/
//	}
        
	public static boolean visited(String name){
		boolean x;
                for(String e:visited){
			if(e.equals(name)) return true;
		}
		return false;
	}
        
        public static void EF(String s, String l){
		for(state e: states){
                    boolean x = false;
                    String a[];
                    a = getChilds(e.getName());
                    for(int i = 0; i < a.length; i++){
                        visited = new ArrayList<String>();
                        x = evalChildEF(e.getName(),s,l);
                        //System.out.println(e.getName() + x);
                        if(x) break;
                    }
                    if(x){
                        e.addLabel(l);
                    }
		}
	}
	
	public static boolean evalChildEF(String name, String s, String l){
		boolean x = true;
		if(visited(name)) return false;
		visited.add(name);
		if(holds(name,s)) return true;
		String a[];
		a = getChilds(name);
		for(int i = 0; i < a.length; i++){
			x = evalChildEF(a[i],s,l);
			if(x) return true;
		}
		return false;
	}
        
        public static void EU(String s,String s2,String l){
            int before, after;
            String[] a;
            for(state e:states){
                if(e.inLabel(s2) || e.inArray(s2)) e.addLabel(l);
            }
            do{
                before = numberLabels();
                
                for(state e:states){
                    if(e.inLabel(s) || e.inArray(s)){
                        a = e.relationsToArray();
                        for(int i = 0; i< a.length; i++){
                            if(holds(a[i],l)){
                                if(!e.inLabel(s) && !e.inArray(s)){
                                    e.addLabel(l);
                                }
                            }
                        }
                    }
                }
                after = numberLabels();
            }while(before != after);
        }
        
        public static void AU(String s,String s2,String l){
            for(state e: states){
                    boolean x = false;
                    visited = new ArrayList<String>();
                    if(holds(e.getName(),s)){
                        x = evalChildsAU(e.getName(),s,s2,l);
                    }
                    //System.out.println(e.getName() + x);
                    if(x){
                        e.addLabel(l);
                    }
            }
        }
        
        public static boolean evalChildsAU(String name, String s, String s2,String l){
		boolean x = false;
		if(visited(name)) return true;
		visited.add(name);
		if(holds(name,s2)) return true;
                if(!holds(name,s)) return false;
		String a[];
		a = getChilds(name);
		for(int i = 0; i < a.length; i++){
                        visited = new ArrayList<String>();
                        if(a[i].equals(name)) return true;
                        x = evalChildsAU(a[i],s,s2,l);
			if(!x) return false;
		}
		return x;
	}
}

/***********************************************************************************************************/

class state{
	
	private String name;
	private ArrayList<String> elements;
	private ArrayList<String> relations;
	private ArrayList<String> labels;
	
	//STATE CREATION
	public state(){		//creates a new void state
		elements = new ArrayList<String>();
		relations = new ArrayList<String>();
		labels = new ArrayList<String>();
	}
	
	public state(String n){		//creates a new state with provided name
		elements = new ArrayList<String>();
		relations = new ArrayList<String>();
		labels = new ArrayList<String>();
		name = n;
	}
	
	//NAME
	public void setName(String n){		//sets or changes the name of the state
		name = n;
	}
	public String getName(){		//fetchs the name of the state
		return name;
	}
	
	//VALUES
	public boolean inArray(String v){		//checks if the state is already labeled with a value
		for(String e: elements){
			if(e.equals(v)){
				return true;
			}
		}
		return false;
	}
	
	public void addValues(String v){		//adds a new value to the state
		elements.add(v);
	}
	
	public void getValues(){			//prints the values of the state
		//for(int i=0; i < elements.size(); i++){
		if(numberValues() > 0){
			int i = 0;
			for(String e: elements){
				if(i > 0)
					System.out.print("," + e);
				else
					System.out.print("\tValues: " + e);
				i++;
			}
			System.out.println("");
		}
		else{
			System.out.println("VOID");
		}
	}
	
	public int numberValues(){
		return elements.size();
	}
	
	//RELATIONS
	public void relationExists(String from, String to){
		
	}
	public void addRelation(String to){
		relations.add(to);
	}
	
	public void getRelations(){
		for(String e: relations){
			System.out.println("\tRelation from: " + name + " to: " + e);
		}
	}
	
	public String[] relationsToArray(){
		String r[] = new String[relations.size()];
		relations.toArray(r);
		return r;
	}
	public int numberRelations(){	
		return relations.size();
	}
	
	//LABELS
	public void addLabel(String s){
		labels.add(s);
	}
	
	public void getLabels(){
		if(labels.size() > 0){
			for(String e: labels){
				System.out.println("\tHolds: " + e);
			}
		}
		else{
			System.out.println("\tHolds:Void");
		}
	}
	
	public boolean inLabel(String v){		//checks if the state is already labeled with a value
		for(String e: labels){
			if(e.equals(v)){
				return true;
			}
		}
		return false;
	}
        
        public int numberLabels(){
            return labels.size();
        }
}