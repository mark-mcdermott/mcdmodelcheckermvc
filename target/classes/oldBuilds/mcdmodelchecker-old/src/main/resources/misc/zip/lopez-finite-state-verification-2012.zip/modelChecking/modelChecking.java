import java.io.*;
import model.*;
import kripke.*;
import ctl.*;

public class modelChecking{
	
	public static void main(String args[]) throws Exception, IOException{
		model md = new model();
				//System.out.println(args[0]);
				
				try{
				boolean d = (new File(args[0])).exists();
				boolean k = (new File(args[0]+"\\kripke.kpk")).exists();
				boolean ct = (new File(args[0]+"\\test.ctl")).exists();
				if (!d || !k || !ct) {
					System.out.println("Directory " + args[0] + " does not exists");
					System.exit(0);
				} else {
					
				}
				}catch(Exception ex){
					System.out.println("Error, you must provide a directory name as an argument.");
					System.exit(0);
				}
                kripke kp = new kripke(new FileInputStream(args[0] + "\\kripke.kpk"));
                kp.Input();
                
                ctl c = new ctl(new FileInputStream(args[0] + "\\test.ctl"));
                c.Input();
                
		md.printModel();
		
		//System.out.println(md.numberRelations("s1"));
		//md.getValues("s1");
		//md.getStates();
		//md.getRelations("s1");
	}
}