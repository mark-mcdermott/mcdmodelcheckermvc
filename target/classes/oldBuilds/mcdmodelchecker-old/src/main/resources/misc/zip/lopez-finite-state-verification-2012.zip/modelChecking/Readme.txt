System is already compilated, only need to run:

java modelChecking directoryname



In case you want to compile again:
the system uses javacc to parse the input files, so if you want to recompile those, you'll
have to enter the ctl folder and run:

	javacc ctl.jj

and for kripke directory:

	javacc kripke.jj

provided that you have javacc installed and in the system path.
NOTE: you can still see the code in ctl.jj and kripke.jj

then from root directory modelChecking:

	javac model\*.java
	javac kripke\*.java
	javac ctl\.java
	javac modelChecking.java

and then execute the program by the command provided at the beggining of this document.

any doubts about this I am reachable by e-mail.
